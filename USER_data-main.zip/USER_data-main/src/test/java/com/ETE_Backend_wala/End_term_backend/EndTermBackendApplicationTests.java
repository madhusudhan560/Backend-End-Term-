package com.ETE_Backend_wala.End_term_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EndTermBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
