package com.ETE_Backend_wala.End_term_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndTermBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndTermBackendApplication.class, args);
	}

}
